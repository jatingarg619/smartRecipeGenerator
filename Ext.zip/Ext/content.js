// Function to fetch substitutions from GPT-4
async function fetchSubstitution(ingredient, diet, servingSize) {
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer YOUR_OPENAI_API_KEY`
            },
            body: JSON.stringify({
                model: "gpt-4o", // Ensure this is a valid model
                messages: [
                    { role: "system", content: "You are a helpful assistant." },
                    { role: "user", content: `Suggest a ${diet} recipe for ${servingSize} servings using the following ingredients: ${ingredient}.` }
                ],
                max_tokens: 5000,
                temperature: 0.5
            })
        });

        const data = await response.json();

        if (data.choices && data.choices.length > 0) {
            return data.choices[0].message.content.trim();
        } else {
            return null;
        }
    } catch (error) {
        return null;
    }
}

// Listen for messages from popup.js


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "convertRecipe") {
        const { servingSize, diet, ingredientsInput } = request;

        const ingredients = ingredientsInput.split(',').map(item => item.trim());
        const ingredientsList = ingredients.join(', ');

        if (diet === "vegan" || diet === "gluten-free") {
            fetchSubstitution(ingredientsList, diet, servingSize).then(response => {
                if (response) {
                    sendResponse({ success: true, results: response });
                } else {
                    sendResponse({ success: false, results: 'No substitution found.' });
                }
            }).catch(error => {
                sendResponse({ success: false, results: 'Error fetching substitution.' });
            });
        } else {
            sendResponse({ success: true, results: ingredientsList });
        }

        // Indicate that the response will be sent asynchronously
        return true;
    }
});
